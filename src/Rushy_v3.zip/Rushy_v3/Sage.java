package Rushy_v3;

import battlecode.common.*;

public class Sage extends Robot {
    public Sage(RobotController rc) throws GameActionException {
        super(rc);
    }

    public void takeTurn() throws GameActionException {
        super.takeTurn();
        // stuff that this type of bot does.
    }
}
